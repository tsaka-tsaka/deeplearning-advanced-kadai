from django.shortcuts import render
from .forms import ImageUploadForm
#import random
from django.conf import settings
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.applications.vgg16 import decode_predictions, preprocess_input
from io import BytesIO
import os
import random
import tempfile
import pandas as pd

# Create your views here.

def predict(request):
    if request.method == 'GET':
        form = ImageUploadForm()
        return render(request, 'home.html', {'form': form})
    if request.method == 'POST':
        # POSTリクエストによるアクセス時の処理を記述
        form = ImageUploadForm(request.POST, request.FILES)
        print(request.FILES)
        
        if form.is_valid():
            #画像の前処理
            img_file = form.cleaned_data['image']
            img_file=BytesIO(img_file.read())            
            img=load_img(img_file, target_size=(224,224))
            img_array=img_to_array(img)
            img_array=img_array.reshape((1,224,224,3))
            img_array=preprocess_input(img_array)
            
            #print(img_array)
            ##モデルの読み込みと予測
            model_path=os.path.join(settings.BASE_DIR, 'prediction', 'models','vgg16.h5')#'dummy_vgg16.h5')
            #print(model_path)
            model=load_model(model_path)
            result=model.predict(img_array)
            #print(result)                     
            #prediction=decode_predictions(result)
            top_classes = decode_predictions(result, top=5)[0]
            #print(top_classes)
            predictions = [(label, score) for (class_id, label, score) in top_classes]
            img_file = form.cleaned_data['image']
            #with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_img_file:
            #    for chunk in img_file.chunks():
            #        temp_img_file.write(chunk)
            #    img_path = temp_img_file.name            
            #    print(img_path)
            img_data=request.POST.get('img_data')
            return render(request, 'home.html', {'form': form, 'predictions': predictions, 'img_data': img_data})
        else:
            form = ImageUploadForm()
            return render(request, 'home.html', {'form': form})