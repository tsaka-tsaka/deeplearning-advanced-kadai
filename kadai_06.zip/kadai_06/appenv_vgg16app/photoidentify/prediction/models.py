from django.db import models
from django.urls import reverse
# Create your models here.

class Img(models.Model):
    img=models.ImageField(blank=True)